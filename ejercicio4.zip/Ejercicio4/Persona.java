package Ejercicio4;

import java.util.Scanner;

public class Persona {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
		Privado eprivado = new Privado("123456787", "Francisco", "Risopatr�n De Lourdes", "Juan Bosco 1786", 976834616, 6000000, "Comuna Las Condes", "Gerencia"); 
		
		Publico epublico = new Publico("152423566", "Fernando", "Mellado Salinas", "Los Laureles 45", 945281947, 780000, "Municipalidad de Los Alamos", "Administrativo");
		
		System.out.println("Empleado Publico\n\n" 
							+ epublico.getRut()
							+"\n"
							+ epublico.getNombres()
							+"\n"
							+ epublico.getApellidos()
							+"\n"
							+ epublico.getDireccion()
							+"\n"
							+ epublico.getTelefono()
							+"\n"
							+ epublico.getSueldo()
							+"\n"
							+ epublico.getMunicipalidad()
							+"\n"
							+ epublico.getDepartamento() 
							+ "\n\n\n\n");
		
		System.out.println("Empleado Privado\n\n" 
							+ eprivado.getRut()
							+"\n"
							+ eprivado.getNombres()
							+"\n"
							+ eprivado.getApellidos()
							+"\n"
							+ eprivado.getDireccion()
							+"\n"
							+ eprivado.getTelefono()
							+"\n"
							+ eprivado.getSueldo()
							+"\n"
							+ eprivado.getComuna()
							+"\n"
							+ eprivado.getEmpresa() );
		
		
		
	}

}
