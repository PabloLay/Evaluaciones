package Ejercicio4;

public class Privado extends Empleado {
	
 String Comuna;
 String Empresa;

 
public String getComuna() {
	return Comuna;
}
public void setComuna(String comuna) {
	Comuna = comuna;
}
public String getEmpresa() {
	return Empresa;
}
public void setEmpresa(String empresa) {
	Empresa = empresa;
}
public Privado() {
	super();
}
public Privado(String rut, String nombres, String apellidos, String direccion, int telefono, double sueldo, String comuna, String empresa) {
	super();
	Rut = rut;
	Nombres = nombres;
	Apellidos = apellidos;
	Direccion = direccion;
	Telefono = telefono;
	Sueldo = sueldo;
	Comuna = comuna;
	Empresa = empresa;
}
 
	
	

}
