package Ejercicio4;

public class Publico extends Empleado {
	
	String Municipalidad;
	String Departamento;

	
	
	public String getMunicipalidad() {
		return Municipalidad;
	}
	public void setMunicipalidad(String municipalidad) {
		Municipalidad = municipalidad;
	}
	public String getDepartamento() {
		return Departamento;
	}
	public void setDepartamento(String departamento) {
		Departamento = departamento;
	}
	public Publico() {
		super();
	}
	public Publico(String rut, String nombres, String apellidos, String direccion, int telefono, double sueldo, String municipalidad, String departamento) {
		super();
		Rut = rut;
		Nombres = nombres;
		Apellidos = apellidos;
		Direccion = direccion;
		Telefono = telefono;
		Sueldo = sueldo;
		Municipalidad = municipalidad;
		Departamento = departamento;
	}
	
	

}
