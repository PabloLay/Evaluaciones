package Ejercicio4;

public class Empleado {

	String Rut;
	String Nombres;
	String Apellidos;
	String Direccion;
	int Telefono;
	double Sueldo;
	

	public String getRut() {
		return Rut;
	}
	public void setRut(String rut) {
		Rut = rut;
	}
	public String getNombres() {
		return Nombres;
	}
	public void setNombres(String nombres) {
		Nombres = nombres;
	}
	public String getApellidos() {
		return Apellidos;
	}
	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}
	public String getDireccion() {
		return Direccion;
	}
	public void setDireccion(String direccion) {
		Direccion = direccion;
	}
	public int getTelefono() {
		return Telefono;
	}
	public void setTelefono(int telefono) {
		Telefono = telefono;
	}
	public double getSueldo() {
		return Sueldo;
	}
	public void setSueldo(double sueldo) {
		Sueldo = sueldo;
	}
	public Empleado() {
		super();
	}
	public Empleado(String rut, String nombres, String apellidos, String direccion, int telefono, double sueldo) {
		super();
		Rut = rut;
		Nombres = nombres;
		Apellidos = apellidos;
		Direccion = direccion;
		Telefono = telefono;
		Sueldo = sueldo;
	}
	
	
	
	
}
