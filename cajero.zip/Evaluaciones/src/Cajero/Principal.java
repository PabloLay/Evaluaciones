package Cajero;

import java.util.Scanner;

public class Principal {	
	static Scanner sc = new Scanner(System.in);
	static Cliente cli = new Cliente();
	static String arreglo1[][] = new String [10][6];
	
	static int arreglo2[][] = new int[10][2];
	static int mov[][] = new int [10][5];
	static int contador[] = {5,5,5};
	static int contmov[] = {1,1,1,1,1,0,0,0,0,0}; 
	static int sesion;
	public static void main(String[] args) {	
		datosPrevios();
		menu1();
	}
	public static void menu1() {
		int op1 = 0;	
		do {
			System.out.println("\nIngrese tipo de usuario\n"
								+"1) Administrador\n"
								+"2) Cliente\n"
								+"3) Salir\n");	
			op1 = sc.nextInt();
			switch(op1) {
				case 1 :			
					LogAdmin();
					break;
				case 2 :
					LoginCliente();
					break;
				case 3 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op1 != 3);		
	}	
	public static void LogAdmin() {
		int repetir = 0;
		do {
			System.out.println("Ingrese Usuario");
			String UsAdmin = sc.next();
			System.out.println("Ingrese Clave Administrador");
			String ClAd = sc.next();
			if (UsAdmin.equals("root") && ClAd.equals("root")){
				menu2();
				repetir=3;
			}else {
				System.out.println("Clave o Usuario Incorrectos");
				repetir++;
			}
		}while(repetir<3);
	}
	public static void menu2() {
		int op2 = 0;	
		do {
			System.out.println("\nIngrese tipo de usuario\n"
								+"1) Crear cuenta\n"
								+"2) Crear cliente\n"
								+"3) Crear clave inicial\n"
								+"4) Salir\n");		
			op2 = sc.nextInt();
			switch(op2) {
				case 1 :
					CCuenta();
					break;
				case 2 :
					CCliente();
					
					break;
				case 3 :
					CClave();
					break;
				case 4 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op2 != 4);			
	}
	public static void CCuenta() {
		if(contador[0]<10) {					
			cli.CrearCuenta();					 				
			arreglo1[contador[0]][0] = Integer.toString(cli.getCuenta());
			arreglo1[contador[0]][1] = cli.getTipoCuenta();
			arreglo2[contador[0]][0] = (cli.getCuenta()+contador[0]+1);
			arreglo2[contador[0]][1] = cli.getSaldo();
			contador[0]++;
		}else {
			System.out.println("\nMaximo de Cuentas creadas\n");
		}
	}
	public static void CCliente() {
		if(contador[1]<10) {					
			cli.CrearCliente();					 				
			arreglo1[contador[1]][2] = cli.getRut(); 
			arreglo1[contador[1]][3] = cli.getNombres();
			arreglo1[contador[1]][4] = cli.getApellidos();
			contador[1]++;
		}else {
			System.out.println("\nMaximo de clientes asignados\n");
		}
	}
	public static void CClave() {
		if(contador[2]<10) {					
			cli.CrearClave();					 				
			arreglo1[contador[2]][5] = cli.getClave(); 		
			contador[2]++;
		}else {
			System.out.println("\nMaximo de claves iniciales asignadas\n");
		}
	}
	public static void LoginCliente() {

	    int repetir = 0;
	    do {
	    	String user="";
	    	String pass="";
		
	    	System.out.println("Porfavor ingrese rut");
	    	user = sc.next();
	    	System.out.println("porfavor ingrese clave");
	    	pass = sc.next();
		
	    	for (int i = 0; i < contador[1]; i++) {
	    		if (user.contentEquals(arreglo1[i][2]) && pass.contentEquals(arreglo1[i][5])) {
	    			sesion = i ;
	    			repetir = 3;
	    			menu3();
	    		}
	    	}	    	
	    	if(repetir!=3) {
	    	invalid();		
	    	repetir++;
	    	}
		}while(repetir < 3);		
	}
	public static void menu3() {
		cli.setCuenta(arreglo2[sesion][0]);
		cli.setSaldo(arreglo2[sesion][1]);
		cli.setTipoCuenta(arreglo1[sesion][1]);
		cli.setRut(arreglo1[sesion][2]);
		cli.setNombres(arreglo1[sesion][3]);
		cli.setApellidos(arreglo1[sesion][4]);
		cli.setClave(arreglo1[sesion][5]);		
		int op3 = 0;	
		do {
			System.out.println("\nIngrese tipo de usuario\n"
								+"1) Abonar\n"
								+"2) Girar\n"
								+"3) Consultar saldo\n"
								+"4) Ultimos movimientos\n"
								+"5) Salir\n");		
			op3 = sc.nextInt();
			switch(op3) {
				case 1 :
					SAbonar();
					break;
				case 2 :
					SGiro();
					break;
				case 3 :
					cli.Saldo();
					break;
				case 4 :
					VerUltiMov();
					break;
				case 5 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op3 != 5);		
	}
	public static void SAbonar() {
		System.out.println("Ingrese monto a abonar");
		int abono = sc.nextInt();
		cli.Abonar(abono);	
		arreglo2[sesion][1] = cli.getSaldo();
		Movimientos(abono);
	}
	public static void SGiro() {
		int giro;	
		int repetir  = 0;
		do {			 
			System.out.println("Ingrese monto a girar");
			giro = sc.nextInt();			
			if (giro <= cli.getSaldo()) {
				cli.Giro(giro);	
				arreglo2[sesion][1] = cli.getSaldo();
				Movimientos(-giro);
				repetir = 3;
				} else {
				System.out.println("Giro excede el maximo de su saldo");	
				repetir++;
			}			
		}while(repetir < 3);		
	}
	
	public static void Movimientos(int Imov) {		
		if (contmov[sesion]<5) {
			mov[sesion][contmov[sesion]] = Imov;
			contmov[sesion]++;	
		}else{
			int j = 1;
			for (int i = 0; i < 4; i++) {
				mov[sesion][i] = mov[sesion][j];
				j++;
			}
			mov[sesion][4] = Imov;	
		}		
	}
	public static void VerUltiMov() {
		for (int i = 0; i < contmov[sesion]; i++) {			
		System.out.println("Movimiento " + (i+1) + ": " + mov[sesion][i]);
		}
	}
	public static void salir() {
		System.out.println("\nSaliendo\n");
	}
	public static void invalid() {
		System.out.println("\nOpcion invalida\n");	}
	public static void datosPrevios() {
		String DatosPrevios[][]= {{"50000","1000000001","Corriente","16125522-k","Pablo","Lay","123456"}
								 ,{"30000","1500000002","Ahorro","14734961-8","Ilse","Aburto","654321"}
								 ,{"75000","2000000003","Vista","15128946-5","Juan","Escobar","plank"}
								 ,{"15000","1000000004","Corriente","17987321-7","Ignacio","Araya","prueba4"}
								 ,{"63000","1500000005","Ahorro","16125522-k","Claudia","Gajardo","pass"}};
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 6; j++) {
				arreglo1[i][j] = DatosPrevios[i][(j+1)];				
			}
			arreglo2[i][0] = Integer.parseInt(DatosPrevios[i][1]);
			arreglo2[i][1] = Integer.parseInt(DatosPrevios[i][0]);
			mov[i][0]=Integer.parseInt(DatosPrevios[i][0]);
			
		}
	}
}

