package Cajero;

import java.util.Scanner;
public class Cuenta {
	static Scanner sc = new Scanner(System.in);
	//variables de la clase
	private int cuenta;
	private int saldo;
	private String tipoCuenta;
	//getters and setters
	public int getCuenta() {
		return cuenta;
	}
	public void setCuenta(int cuenta) {
		this.cuenta = cuenta;
	}
	public int getSaldo() {
		return saldo;
	}
	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}
	public String getTipoCuenta() {
		return tipoCuenta;
	}
	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}	
	//constructor clase SP
	public Cuenta() {
		super();
	}
	//metodos de la clase
	public void CrearCuenta(){		
		int selec = 0;
		//menu metodo cuenta
		System.out.println("Seleccione el tipo de cuenta a crear:\n"
							+ "1) Corriente "
							+ "2) Ahorro"
							+ "3) Vista");		
		selec = sc.nextInt();		
		//switch men� tipo de cuenta
		switch (selec) {
		case 1:
			tipoCuenta = "Corriente";
			cuenta = 10 * 100000000;			
			break;
		case 2:
			tipoCuenta = "Ahorro";
			cuenta = 15 * 100000000;			
			break;
		case 3:
			tipoCuenta = "Vista";
			cuenta = 20 * 100000000;			
			break;
		default:
			System.out.println("Opcion invalida, seleccione tipo de cuenta\n\n");
			break;		
		} 		
		saldo = 0;		
	}
	//metodo abonar
	public void Abonar(int abono) {
		saldo += abono;
		System.out.println("Su nuevo saldo es de $"+saldo);
	}
	//metodo giro
	public void Giro(int giro) {
		saldo -= giro;
		System.out.println("Su nuevo saldo es de $"+saldo);
	}
}

















