package Cajero;
import java.util.Scanner;
public class Cliente extends Cuenta{
	static Scanner sc =new Scanner(System.in);
	//Variables Cliente
	private String rut;
	private String nombres;
	private String apellidos;
	private String clave;
	//contructores cliente SP
	public Cliente() {
		super();
	}
	//Getters and setters
	public String getRut() {
		return rut;
	}
	public void setRut(String rut) {
		this.rut = rut;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getClave() {
		return clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	//Metodo crear cliente
	public void CrearCliente() {
		//variables de ingreso para verificacion
		String rut1;
		//variable para ciclo de repeticion
		int p;
		//inicio ciclo
		do {
			p=0;
			System.out.println("Ingrese Rut");
			rut1=sc.next();
			//validador rut
			if (validarRut(rut1) ==true) {
				rut=rut1;
				System.out.println("Ingrese Nombres");
				nombres=sc.next();
				System.out.println("Ingrese Apellidos");
				apellidos=sc.next();
				
			}else {
				System.out.println("rut invalido");
				p=1;
			}
		}while(p==1);
	}
	//M�todo crear clave
	public void CrearClave() {
		System.out.println("Ingrese Clave inicial");
		clave=sc.next();
	}
	//m�todo cambiar clave
	public void CambiarClave() {
		//Variables m�todo
		String comp1, clave1;
		//variable y contador para ciclo de repeticion
		int rep, cont=0;
		//Inicio metodo do
		do {
			rep=0;
			System.out.println("Ingresar Clave actual");
			comp1 =sc.next();
			//Ingreso nueva clave
			if (comp1.equals(clave)) {
				System.out.println("Ingrese nueva clave");
				clave1=sc.next();
				System.out.println("Ingrese clave nuevamente");
				clave=sc.next();
				//Comparacion Clave
				if (clave1.equals(clave)) {
					System.out.println("Clave cambiada con �xito");
				}else {
					System.out.println("las claves no coinciden");
				}
			}else {
				System.out.println("Clave erronea, Favor intente de nuevo");
				rep=1;
			}
			cont++;
			System.out.println(cont);
			System.out.println(rep);
		}while(rep == 1 && cont!=3);
		 if(cont==3) {
			 System.out.println("Cuenta Bloqueada");
		 }
	}
	//metodo saldo
	public void Saldo() {
		System.out.println("N� Cuenta	   : " + getCuenta());
		System.out.println("Cuenta         : " + getTipoCuenta());
		System.out.println("Nombre cliente : " + nombres + " " + apellidos);
		System.out.println("Rut            : " + rut);
		System.out.println("Saldo 		   :  $" + getSaldo());
	}
	//Metodo Validacion Rut
	public static boolean validarRut(String rut1) {
		boolean validacion = false;
		try {
			rut1 =  rut1.toUpperCase();
			rut1 = rut1.replace(".", "");
			rut1 = rut1.replace("-", "");
			int rutAux = Integer.parseInt(rut1.substring(0, rut1.length() - 1));
			char dv = rut1.charAt(rut1.length() - 1);
			int m = 0, s = 1;
			for (; rutAux != 0; rutAux /= 10) {
				s = (s + rutAux % 10 * (9 - m++ % 6)) % 11;
			}
			if (dv == (char) (s != 0 ? s + 47 : 75)) {
				validacion = true;
			}
		} catch (java.lang.NumberFormatException e) {
		} catch (Exception e) {
		}
		return validacion;
	}
}
