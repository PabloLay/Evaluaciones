package Cajero;

import java.util.Scanner;
//Clase Principal
public class Principal {	
	//Scanner ingreso de datos
	static Scanner sc = new Scanner(System.in);
	//Creaci�n Cliente
	static Cliente cli = new Cliente();
	//Arreglo 1 {cuenta, tipo de cuenta, rut, nombre, apellido, clave}
	static String arreglo1[][] = new String [10][6];
	//Arreglo 2 {cuenta, saldo}
	static int arreglo2[][] = new int[10][2];
	//Arreglo almacenar movimientos de giros y abonos
	static int mov[][] = new int [10][5];
	//Arreglo numera cuentas y usuarios creados
	static int contador[] = {5,5};
	//Arreglo cuenta movimientos de cada usuario
	static int contmov[] = {1,1,1,1,1,0,0,0,0,0}; 
	//Variable indica indice respectivo de usuario loggeado
	static int sesion;
	
	//Instancia Principal
	public static void main(String[] args) {	
		datosPrevios();
		menu1();
	}
	//Men� principal del programa
	public static void menu1() {
		int op1 = 0;	
		do {
			System.out.println("\nIngrese tipo de usuario\n"
								+"1) Administrador\n"
								+"2) Cliente\n"
								+"3) Salir\n");	
			op1 = sc.nextInt();
			switch(op1) {
				case 1 :			
					LogAdmin();
					break;
				case 2 :
					LoginCliente();
					break;
				case 3 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op1 != 3);		
	}
	//M�todo de Log administrados
	public static void LogAdmin() {
		int repetir = 0;
		do {
			System.out.println("Ingrese Usuario");
			String UsAdmin = sc.next();
			System.out.println("Ingrese Clave Administrador");
			String ClAd = sc.next();
			if (UsAdmin.equals("root") && ClAd.equals("root")){
				menu2();
				repetir=3;
			}else {
				System.out.println("Clave o Usuario Incorrectos");
				repetir++;
			}
		}while(repetir<3);
	}
	//Men� interno Administrados
	public static void menu2() {
		int op2 = 0;	
		do {
			System.out.println("\nIngrese tipo de usuario\n"
								+"1) Crear cuenta\n"
								+"2) Crear cliente\n"
								+"3) Mostrar Clientes\n"
								+"4) Salir\n");		
			op2 = sc.nextInt();
			switch(op2) {
				case 1 :
					CCuenta();
					break;
				case 2 :
					CCliente();
					
					break;
				case 3 :
					MostrarClientes();
					break;
				case 4 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op2 != 4);			
	}
	//Instancias men� administrador
		//M�todo Crear Cuenta
		public static void CCuenta() {
			if(contador[0]<10) {					
				cli.CrearCuenta();					 				
				arreglo1[contador[0]][0] = Integer.toString(cli.getCuenta());
				arreglo1[contador[0]][1] = cli.getTipoCuenta();
				arreglo2[contador[0]][0] = (cli.getCuenta()+contador[0]+1);
				arreglo2[contador[0]][1] = cli.getSaldo();
				contador[0]++;
			
			}else {
				System.out.println("\nMaximo de Cuentas creadas\n");
			}
		}
		//M�todo Crear Cliente
		public static void CCliente() {
			if(contador[1]<10) {					
				cli.CrearCliente();					 				
				arreglo1[contador[1]][2] = cli.getRut(); 
				arreglo1[contador[1]][3] = cli.getNombres();
				arreglo1[contador[1]][4] = cli.getApellidos();
				arreglo1[contador[1]][5] = cli.getClave();
				contador[1]++;
			}else {
				System.out.println("\nMaximo de clientes asignados\n");
			}
		}
		//M�todo Impresi�n de Clientes  muestra todos los datos ingresados
		public static void MostrarClientes() {
			for(int i=0; i< contador[1];i++) {
				System.out.println("Cliente "+arreglo1[i][3] +" "+arreglo1[i][4]
					+"\nRut "+arreglo1[i][2]
					+"\nCuenta "+ arreglo1[i][1]+" N� "+arreglo2[i][0]
					+"\nsaldo $"+arreglo2[i][1]
					+"\n\n\n");
			}
		}
	//M�todo Log Cliente
	public static void LoginCliente() {

	    int repetir = 0;
	    do {
	    	String user="";
	    	String pass="";
		
	    	System.out.println("Porfavor ingrese rut");
	    	user = sc.next();
	    	user =  user.toUpperCase();
			user = user.replace(".", "");
			user = user.replace("-", "");
	    	System.out.println("porfavor ingrese clave");
	    	pass = sc.next();
		
	    	for (int i = 0; i < contador[1]; i++) {
	    		if (user.equals(arreglo1[i][2]) && pass.equals(arreglo1[i][5])){
	    			sesion = i ;
	    			repetir = 3;
	    			menu3();
	    		}	
	    	}
	    	if(repetir!=3) {
	    	
	    	invalid();
	    	repetir++;
	    	}
	    	
		}while(repetir < 3);		
	}
	//Men� interno Cliente
	public static void menu3() {
		cli.setCuenta(arreglo2[sesion][0]);
		cli.setSaldo(arreglo2[sesion][1]);
		cli.setTipoCuenta(arreglo1[sesion][1]);
		cli.setRut(arreglo1[sesion][2]);
		cli.setNombres(arreglo1[sesion][3]);
		cli.setApellidos(arreglo1[sesion][4]);
		cli.setClave(arreglo1[sesion][5]);		
		int op3 = 0;	
		do {
			System.out.println("\nIngrese opcion\n"
								+"1) Abonar\n"
								+"2) Girar\n"
								+"3) Consultar saldo\n"
								+"4) Ultimos movimientos\n"
								+"5) Cambiar clave\n"
								+"6) Salir\n");		
			op3 = sc.nextInt();
			switch(op3) {
				case 1 :
					SAbonar();
					break;
				case 2 :
					SGiro();
					break;
				case 3 :
					cli.Saldo();
					break;
				case 4 :
					VerUltiMov();
					break;
				case 5 :
					cli.CambiarClave();
					arreglo1[sesion][5]= cli.getClave();
					break;
				case 6 :
					salir();
					break;
				default :
					invalid();
					break;		
			}
		}while(op3 != 6);		
	}
	
	//Instancias men� cliente
	
		//M�todo Abono
		public static void SAbonar() {
			System.out.println("Ingrese monto a abonar");
			int abono = sc.nextInt();
			cli.Abonar(abono);	
			arreglo2[sesion][1] = cli.getSaldo();
			Movimientos(abono);
		}
		
		//M�tedo Giro
		public static void SGiro() {
			int giro;	
			int repetir  = 0;
			do {			 
				System.out.println("Ingrese monto a girar");
				giro = sc.nextInt();			
				if (giro <= cli.getSaldo()) {
					cli.Giro(giro);	
					arreglo2[sesion][1] = cli.getSaldo();
					Movimientos(-giro);
					repetir=3;
				} else {
					System.out.println("Giro excede el maximo de su saldo");	
					repetir++;
				}			
			}while(repetir < 3);		
		}
		
		//M�todo movimientos (lleva el resgitro de movimientos realizados)
		public static void Movimientos(int Imov) {		
			if (contmov[sesion]<5) {
				mov[sesion][contmov[sesion]] = Imov;
				contmov[sesion]++;	
			}else{
				int j=1;
				for (int i = 0; i < 4; i++) {
					mov[sesion][(i)] = mov[sesion][(j)];
					j++;
				}
				mov[sesion][(4)] = Imov;
			}		
		}
		
		//M�todo ver ultimo movimiento (impresi�n de movimientos realizados)
		public static void VerUltiMov() {
			for (int i = 0; i < contmov[sesion]; i++) {			
				System.out.println("Movimiento " + (i+1) + ": " + mov[sesion][i]);
			}
		}
		
	//M�todo Salir (estupido es para salir)
	public static void salir() {
		System.out.println("\nSaliendo\n");
	}
	
	//M�todo invalidaci�n
	public static void invalid() {
		System.out.println("\nOpcion invalida\n");
	}
	
	//Instancia Datos Previos
	public static void datosPrevios() {
		String DatosPrevios[][]= {{"50000","1000000001","Corriente","16125522K","Pablo","Lay","123456"}
								 ,{"30000","1500000002","Ahorro","147349618","Ilse","Aburto","654321"}
								 ,{"75000","2000000003","Vista","151289465","Juan","Escobar","plank"}
								 ,{"15000","1000000004","Corriente","179873217","Ignacio","Araya","prueba4"}
								 ,{"63000","1500000005","Ahorro","13125522K","Claudia","Gajardo","pass"}};
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 6; j++) {
				arreglo1[i][j] = DatosPrevios[i][(j+1)];				
			}
			arreglo2[i][0] = Integer.parseInt(DatosPrevios[i][1]);
			arreglo2[i][1] = Integer.parseInt(DatosPrevios[i][0]);
			mov[i][0]= Integer.parseInt(DatosPrevios[i][0]); 
		}
	}
//llave cierre clase
}

