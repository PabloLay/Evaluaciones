package EvaluacionModulo;

public class Lavadora extends Electrodom�stico {
	private float carga;
	
	protected final static float Kcarga = 5;	

	public Lavadora() {
		super(KprecioB, Kcolor, KconsumoE, Kpeso);
		this.carga=Kcarga;
	}
	
	public Lavadora(int precioB, float peso) {
		super(precioB, Kcolor, KconsumoE, peso);		
		this.carga=Kcarga;
	}
	
	public Lavadora(int precioB, String color, char consumoE, float peso, float carga) {
		super(precioB, color, consumoE, peso);
		this.carga = carga;
	}

	public float getCarga() {
		return carga;
	}

	public void setCarga(float carga) {
		this.carga = carga;
	}
	
	public int precioFinal() {
		int aumento = super.precioFinal();
		if (carga > 30) {
			aumento += 40000;
		}
		return aumento;		
	}


}
