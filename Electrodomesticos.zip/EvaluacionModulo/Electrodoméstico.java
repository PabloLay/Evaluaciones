package EvaluacionModulo;

public class Electrodom�stico {
	private int precioB;
	private String color;
	private char consumoE;
	private float peso;
	
	protected final static int KprecioB = 100000;
	protected final static String Kcolor = "BLANCO";
	protected final static char KconsumoE = 'F';
	protected final static float Kpeso = 5f;
	
	public Electrodom�stico() {
		super();
		this.precioB = KprecioB;
		this.color = Kcolor;
		this.consumoE = KconsumoE;
		this.peso = Kpeso;
	}
		
	public Electrodom�stico(int precioB, float peso) {
		super();
		this.precioB = precioB;
		this.color = Kcolor;
		this.consumoE = KconsumoE;
		this.peso = peso;
	}

	public Electrodom�stico(int precioB, String color, char consumoE, float peso) {
		super();
		this.precioB = precioB;
		this.color = comprobarColor(color);
		this.consumoE = comprobarConsumoEnergtico(consumoE);
		this.peso = peso;
	}

	public int getPrecioB() {
		return precioB;
	}
	public void setPrecioB(int precioB) {
		this.precioB = precioB;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public char getConsumoE() {
		return consumoE;
	}
	public void setConsumoE(char consumoE) {
		this.consumoE = consumoE;
	}
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}
	
	public char comprobarConsumoEnergtico(char letra) {		
		if(letra == 'A' || letra == 'B' || letra == 'C' || letra == 'D' || letra == 'E') {			
			return letra;			
		} else {
			return KconsumoE;
		}
	}
	
	public String comprobarColor(String color){
		if (color.equals("NEGRO") || color.equals("ROJO") || color.equals("AZUL") || color.equals("GRIS")) {
			return color;			
		} else {
			return Kcolor;
		}
	}
	
	public  int precioFinal() {		
		 int aumento = 0;
	        switch(consumoE){
	            case 'A':
	                aumento += 85000;
	                break;
	            case 'B':
	                aumento += 70000;
	                break;
	            case 'C':
	            	aumento += 50000;
	                break;
	            case 'D':
	            	aumento += 40000;
	                break;
	            case 'E':
	            	aumento += 25000;
	                break;
	            default:
	                aumento += 8500;
	                break;
	        }
	   
	        if(peso < 19f){
	            aumento += 8500;
	        }else if(peso <49){
	            aumento += 40000;
	        }else if(peso <= 79){
	            aumento += 70000;	        
	        }else{
	            aumento += 85000;
	        }
	   
	        return precioB + aumento;
	}
	

}
