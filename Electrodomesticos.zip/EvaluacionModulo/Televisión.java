package EvaluacionModulo;

public class Televisi�n extends Electrodom�stico{
	private int resoluci�n;
	private boolean TDT;
	
	protected final static int Kresoluci�n = 20;
	protected final static boolean KTDT = false;
	
	public Televisi�n() {
		super(KprecioB, Kcolor, KconsumoE, Kpeso);
		this.resoluci�n = Kresoluci�n;
		this.TDT = KTDT;
	}
	
	public Televisi�n(int precioB, float peso) {
		super(precioB, Kcolor, KconsumoE, peso);
		this.resoluci�n = Kresoluci�n;
		TDT = KTDT;
	}

	public Televisi�n(int precioB, String color, char consumoE, float peso, int resoluci�n, boolean TDT) {
		super(precioB, color, consumoE, peso);
		this.resoluci�n = resoluci�n;
		this.TDT = TDT;
	}

	public int getResoluci�n() {
		return resoluci�n;
	}

	public void setResoluci�n(int resoluci�n) {
		this.resoluci�n = resoluci�n;
	}

	public boolean isTDT() {
		return TDT;
	}

	public void setTDT(boolean tDT) {
		TDT = tDT;
	}
	
	public int precioFinal() {
		int aumento = super.precioFinal();
		if (resoluci�n > 40 ) {
			aumento *= 1.3;
		}
		if (TDT = true) {			
			aumento += 45000; 			
		}
		return aumento;		
	}
	

}
