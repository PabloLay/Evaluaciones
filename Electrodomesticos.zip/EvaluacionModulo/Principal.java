package EvaluacionModulo;

public class Principal {
	public static void main(String[] args) {
        int SElectro = 0 ;
        int STele = 0 ;
        int SLav = 0 ;		
        
		Electrodom�stico arrayElectro[]=new Electrodom�stico[10];     
		
		arrayElectro[0] = new Lavadora(100000, "BLANCO",'B', 5f, 5f);
        arrayElectro[1] = new Televisi�n(100000, "BLANCO",'B', 5f, 20, true);
        arrayElectro[2] = new Electrodom�stico(200000, "AZUL", 'C', 15f);
        arrayElectro[3] = new Televisi�n(200000, "ROJO", 'D', 10f, 32, false);
        arrayElectro[4] = new Lavadora(300000, "GRIS", 'E', 25f, 20f);
        arrayElectro[5] = new Electrodom�stico(300000, "AZUL", 'F', 15f);
        arrayElectro[6] = new Lavadora(400000, "ROJO", 'A', 30f, 30f);
        arrayElectro[7] = new Televisi�n(400000, "BLANCO", 'B', 20f, 55, false);
        arrayElectro[8] = new Lavadora(500000, "GRIS", 'C', 45f, 40f);
        arrayElectro[9] = new Televisi�n(500000, "NEGRO", 'D', 25f, 60, true);        
  
        
        for(int i=0;i<arrayElectro.length;i++){      
            if(arrayElectro[i] instanceof Electrodom�stico){            	
            	SElectro += arrayElectro[i].precioFinal();
            }
            if(arrayElectro[i]  instanceof Lavadora){
            	SLav += ((arrayElectro[i])).precioFinal();                	   
            }
            if(arrayElectro[i]  instanceof Televisi�n){
            	STele += arrayElectro[i].precioFinal(); 
            }
        }      
        System.out.println("La suma de los electrodomesticos es	:	$ " + SElectro);
        System.out.println("La suma de las lavadoras es 		:	$ " + SLav);
        System.out.println("La suma de las televisiones es 		: 	$ " + STele);
	}
}


