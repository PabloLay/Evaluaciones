package Evaluacion01;

public class AutomovilNuevo {
	String marca;
	String modelo;
	int a�o;
	double precio;
	
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getA�o() {
		return a�o;
	}
	public void setA�o(int a�o) {
		this.a�o = a�o;
	}
	
	
	public AutomovilNuevo(String marca, String modelo, int a�o, double precio) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.a�o = a�o;
		this.precio = precio;
	}
	
	public void preciofinal() {		
		double Pf;		
		Pf = (precio*1.24) + 100000 ;					
	}

}
