package Evaluacion01;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UsuariosBT {	
	static Scanner sc = new Scanner(System.in);
	static Date fa = new Date ();
	static int idtargeta;
	static String tipoUBT;
	static int saldo;
	static Date ultimaFecha;
	static String es="";
	static int op = 0;
	static Date testDate = null;

	public static void main(String[] args) {
		do { 			
			System.out.println("	Menu Bio-Tren	\n \n" 
					
				+ "Elija una de las siguientes opciones : \n \n"
											
				+ "1). Crear Usuario \n"
				
				+ "2). Abonar \n"
				
				+ "3). Pagar Viaje \n"
				
				+ "4). Consulatar Saldo \n"
				
				+ "5). Verificar estado \n"
				
				+ "6). Salir \n");
			
				op = sc.nextInt();
				
				System.out.println("  ");
			
				switch(op) {				
				case 1:
						crear();
					break;					
				case 2:
						
						Abonar();
						
					break;
				case 3:
						pagar();
					break;
				case 4:
						System.out.println("El saldo Actual es de $"+saldo);
					break;
				case 5:									
						System.out.println("El ususario esta " + es);
					break;
				case 6:
					System.out.println("Saliendo del programa \n");
					break;
				default:
					 System.out.println("opcion invalida, elija una opcion segun lista \n \n \n \n");
					break;				
				}		
				try {
					Thread.sleep(3*1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}while(op != 6);		
		System.out.println("Fin");		
	}
	
	public static void fechasini() {
		System.out.println("Introduzca la fecha con formato dd/mm/yyyy");
        String fecha = sc.nextLine();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String date = fecha;
        try{
            testDate = df.parse(date);
        } catch (Exception e){ System.out.println("invalid format");}
	}
	
	public static void crear() {
		String tipo[]= {"Comun","TNE","Bip"};
		int i=0;
		System.out.println("Ingrese datos de nuevo usuario \n"
		+ "Ingrese Rut sin digito verificador");	
		idtargeta = sc.nextInt();
		System.out.println("\n Ingrese tipo de usuario: \n" 
		+ "1).Comun \n" 
		+ "2).TNE \n" 
		+ "3).Bip");
		i = sc.nextInt();
		tipoUBT = tipo[i];
		System.out.println("\nIngrese abono al saldo");
		saldo = sc.nextInt();
		fechasini();
		ultimaFecha =  testDate;
		Des_Act();
		Mostrar();		
	}
	
	public static void Abonar() {	
		Des_Act();
		int nuevo = 0 ;
		System.out.println("\nIngrese abono al saldo");
		nuevo = sc.nextInt();
		saldo += nuevo;	
		ultimaFecha = fa;
	}	
	
	public static void pagar() {		
		Des_Act();
		if (es == "Activada") {			
			int Com = 370;
			int TNE = 180;
			int Bip = 250;			
			if(tipoUBT == "Comun") {			
				saldo -= Com;
				System.out.println("Se a descontado $"+Com+" de su saldo");			
			}else if(tipoUBT == "TNE") {
				saldo -= TNE;
				System.out.println("Se a descontado $"+TNE+" de su saldo");
			}else {
				saldo -= Bip;
				System.out.println("Se a descontado $"+Bip+" de su saldo");
			}		
			ultimaFecha = fa;
			Mostrar();		
		}else{
			System.out.println("Su targeta esta inactiva");
		}
		
		
	}
	
	public static void Mostrar() {	
		System.out.println("\n Usuario \nNumero de targeta: " + idtargeta 
				+ "\nTipo de usuario: " + tipoUBT 
				+ "\nSaldo: " + saldo 
				+ "\nEstado: " + es 
				+ "\n \n \n \n" );		
	}	
	
	public static void Des_Act() {		
		int dias = (int) ((fa.getTime() - ultimaFecha.getTime())/86400000);
        if (dias>=365) {
           es = "Desactivada";
        }   else {
           es = "Activada";
        }		
	}
	
	


}
